export class UserFetch {
    id:number;
    title:string;
    author:string;
    subject_category:string;
}